chmod +x $LIDE_PATH/bin/linux/x64/lua
$LIDE_PATH/bin/linux/x64/lua $LIDE_PATH/lide.lua $1 $2 $3 $4 $5 $6 $7